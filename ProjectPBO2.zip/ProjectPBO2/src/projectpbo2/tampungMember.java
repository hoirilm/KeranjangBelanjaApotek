/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpbo2;

/**
 *
 * @author anonymous
 */
public class tampungMember {
    public static int baris = 0;
    public static String ID_PASIEN[] = new String[999999];
    public static String NAMA[] = new String[999999];
    public static String ALAMAT[] = new String[999999];
    public static String NO_TLPN[] = new String[999999];
    public static String TANGGAL[] = new String[999999];
    public static String PAKET[] = new String[999999];
    public static String PASSWORD[] = new String[999999];
}
