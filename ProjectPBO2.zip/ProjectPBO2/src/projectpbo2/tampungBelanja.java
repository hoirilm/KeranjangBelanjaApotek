/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpbo2;

/**
 *
 * @author anonymous
 */
public class tampungBelanja {
    public static int baris = 0;
    public static String PRODUK[] = new String[999999];
    public static int JUMLAH[] = new int[999999];
    public static int TOTALJUMLAH;
    public static String HARGA[] = new String[999999];
    public static int TOTALHARGA;
}
